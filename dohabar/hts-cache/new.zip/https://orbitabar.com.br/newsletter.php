<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="http://ogp.me/ns/fb#">
<head>
<meta charset="UTF-8" />

<title>
Página não encontrada | Órbita Bar</title>

<link rel="alternate" type="application/rss+xml" title="Órbita Bar RSS Feed" href="https://orbitabar.com.br/feed/" />

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">

<link rel="pingback" href="https://orbitabar.com.br/xmlrpc.php" />

<link href="https://orbitabar.com.br/wp-content/themes/orbitabar/css/style.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700,800" rel="stylesheet">

<link rel="shortcut icon" href="https://orbitabar.com.br/wp-content/themes/orbitabar/favicon.ico">

<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/orbitabar.com.br\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.2.16"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])?!1:!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://orbitabar.com.br/wp-includes/css/dist/block-library/style.min.css?ver=5.2.16' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://orbitabar.com.br/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.1.3' type='text/css' media='all' />
<link rel='stylesheet' id='fancybox-css'  href='https://orbitabar.com.br/wp-content/plugins/easy-fancybox/css/jquery.fancybox.min.css?ver=1.3.24' type='text/css' media='screen' />
<script type='text/javascript' src='https://orbitabar.com.br/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script type='text/javascript' src='https://orbitabar.com.br/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<link rel='https://api.w.org/' href='https://orbitabar.com.br/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://orbitabar.com.br/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://orbitabar.com.br/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.2.16" />
		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		
<script src="https://orbitabar.com.br/wp-content/themes/orbitabar/js/jquery-1.11.2.min.js"></script>
<script type="text/javascript" src="https://orbitabar.com.br/wp-content/themes/orbitabar/js/menu-mobile.js"></script>


</head>

<body data-rsssl=1 class="error404">

<div id="header">
	<div class="container">
		<div id="logo">
        	<a href="https://orbitabar.com.br"><img src="https://orbitabar.com.br/wp-content/themes/orbitabar/images/logo.png" alt="Órbita Bar" title="Órbita Bar" /></a>
        </div>

        <div id="nav-top">
        	<ul>
				<li><a href="https://orbitabar.com.br/nossa-historia">NOSSA HISTÓRIA</a></li>
            	<li><a href="https://orbitabar.com.br/contato">CONTATO</a></li>
                <li><a href="https://orbitabar.com.br/responsabilidade-social">RESPONSABILIDADE SOCIAL</a></li>
                <li><a href="javascript:void(0)" onclick="$('html,body').animate({scrollTop: $('#newsletter').offset().top}, 2000);">CADASTRE NEWSLETTER</a></li>
            </ul>
        </div>

        <span class="menu-mobile"><img src="https://orbitabar.com.br/wp-content/themes/orbitabar/images/menu-abrir.png" alt="Menu" /></span>

        <div id="nav">
        	<div class="menu-nav-container"><ul id="menu-nav" class="menu"><li id="menu-item-17" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-17"><a href="https://orbitabar.com.br/">HOME</a></li>
<li id="menu-item-196" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-196"><a href="https://orbitabar.com.br/programacao/">PROGRAMAÇÃO</a></li>
<li id="menu-item-22" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22"><a href="https://orbitabar.com.br/seu-evento-na-nossa-casa/">SEU EVENTO NA NOSSA CASA</a></li>
<li id="menu-item-18" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18"><a href="https://orbitabar.com.br/galeria/">GALERIA</a></li>
<li id="menu-item-19" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19"><a href="https://orbitabar.com.br/listas-de-aniversario/">LISTAS DE ANIVERSÁRIO</a></li>
</ul></div>        </div>
    </div>
</div> <!--fim do header-->
	

<div id="middle">
	<div class="container">
    
        	
        <div id="box_titulo" style="margin:100px 0 0; width:100%; float:left">
    		<h2>Pagina não encontrada (Erro 404)</h2>
    	</div>
<p>O arquivo pode ter sido removido ou renomeado. Certifique-se de verificar a ortografia. Se tudo isso falhar, você pode <a href="javascript:history.back()">voltar para a página de onde veio</a>, ou voltar para a <a href="https://orbitabar.com.br/">página inicia</a>.</p>        
    
    </div>
</div>

<script type="text/javascript">
		function submitNewsletter() {
			if ($('#email').val()) {
				$.post('https://orbitabar.com.br/newsletter.php', {
					email: $('#email').val()
				}, function(a) {alert('Cadastro incluído!');window.location = window.location;}, "json");
			}else {
				alert('Necessário preencher o email.');
			}
		}
</script>

<div id="newsletter">
	<div class="container">
    	<h2>NOVIDADES? CADASTRE-SE</h2>
        <p>Nosso email semanal mantém você atualizado com notícias sobre eventos futuros, noites e todas as coisas.</p>

         <input id="email" placeholder="digite seu email" type="text">
		 <input type="button" value="ENVIAR" onclick="submitNewsletter();"/>

	</div>
</div> <!--FIM DA NEWSLETTER-->

<div id="footer">
	<div class="container">
    	<div id="logo_footer">
        	<img src="https://orbitabar.com.br/wp-content/themes/orbitabar/images/logo_footer.png" />
        </div>
    	<div id="contatos">
        	<span><strong>CONTATOS</strong><br /><br />

            <address>R. Dragão do Mar, 207<br />
            Praia de Iracema - Fortaleza - CE</address><br />

            85 3453.1421<br /><br />

            orbitabar@orbitabar.com.br</span>
        </div>
        <div id="horario">
        	<span><strong>HORÁRIO DE FUNCIONAMENTO</strong><br /><br />

            de Quinta a Domingo<br />
            21:00 às 05:00</span>
        </div>
        <div id="siga">
        	<span><strong>SIGA-NOS</strong></span><br /><br />

            <a href="https://www.facebook.com/OrbitaBar/" target="_blank"><img src="https://orbitabar.com.br/wp-content/themes/orbitabar/images/icon_facebook.png" /></a>
            <a href="https://twitter.com/orbitabar" target="_blank"><img src="https://orbitabar.com.br/wp-content/themes/orbitabar/images/icon_twitter.png" /></a>
            <a href="https://www.instagram.com/orbitabar/" target="_blank"><img src="https://orbitabar.com.br/wp-content/themes/orbitabar/images/icon_instagram.png" /></a>
            <a href="https://www.youtube.com/user/orbitabar" target="_blank"><img src="https://orbitabar.com.br/wp-content/themes/orbitabar/images/icon_youtube.png" /></a>
            <br /><br />
			<a href="http://soim.com.br" target="_blank"><img src="https://orbitabar.com.br/wp-content/themes/orbitabar/images/soim.png" /></a>
        </div>
    </div>
</div>
<div class="modal"></div>

<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/orbitabar.com.br\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://orbitabar.com.br/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.1.3'></script>
<script type='text/javascript' src='https://orbitabar.com.br/wp-content/plugins/easy-fancybox/js/jquery.fancybox.min.js?ver=1.3.24'></script>
<script type='text/javascript'>
var fb_timeout, fb_opts={'overlayShow':true,'hideOnOverlayClick':true,'showCloseButton':true,'margin':20,'centerOnScroll':false,'enableEscapeButton':true,'autoScale':true };
if(typeof easy_fancybox_handler==='undefined'){
var easy_fancybox_handler=function(){
jQuery('.nofancybox,a.wp-block-file__button,a.pin-it-button,a[href*="pinterest.com/pin/create"],a[href*="facebook.com/share"],a[href*="twitter.com/share"]').addClass('nolightbox');
/* IMG */
var fb_IMG_select='a[href*=".jpg"]:not(.nolightbox,li.nolightbox>a),area[href*=".jpg"]:not(.nolightbox),a[href*=".jpeg"]:not(.nolightbox,li.nolightbox>a),area[href*=".jpeg"]:not(.nolightbox),a[href*=".png"]:not(.nolightbox,li.nolightbox>a),area[href*=".png"]:not(.nolightbox),a[href*=".webp"]:not(.nolightbox,li.nolightbox>a),area[href*=".webp"]:not(.nolightbox)';
jQuery(fb_IMG_select).addClass('fancybox image');
var fb_IMG_sections=jQuery('.gallery,.wp-block-gallery,.tiled-gallery');
fb_IMG_sections.each(function(){jQuery(this).find(fb_IMG_select).attr('rel','gallery-'+fb_IMG_sections.index(this));});
jQuery('a.fancybox,area.fancybox,li.fancybox a').each(function(){jQuery(this).fancybox(jQuery.extend({},fb_opts,{'transitionIn':'elastic','easingIn':'easeOutBack','transitionOut':'elastic','easingOut':'easeInBack','opacity':false,'hideOnContentClick':false,'titleShow':true,'titlePosition':'over','titleFromAlt':true,'showNavArrows':true,'enableKeyboardNav':true,'cyclic':false}))});};
jQuery('a.fancybox-close').on('click',function(e){e.preventDefault();jQuery.fancybox.close()});
};
var easy_fancybox_auto=function(){setTimeout(function(){jQuery('#fancybox-auto').trigger('click')},1000);};
jQuery(easy_fancybox_handler);jQuery(document).on('post-load',easy_fancybox_handler);
jQuery(easy_fancybox_auto);
</script>
<script type='text/javascript' src='https://orbitabar.com.br/wp-content/plugins/easy-fancybox/js/jquery.easing.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://orbitabar.com.br/wp-content/plugins/easy-fancybox/js/jquery.mousewheel.min.js?ver=3.1.13'></script>
<script type='text/javascript' src='https://orbitabar.com.br/wp-includes/js/wp-embed.min.js?ver=5.2.16'></script>


<script>
	$body = $("body");
	$(function()
	{
		$(document).on({
				ajaxStart: function () {
						$body.addClass("loading");
				},
				ajaxStop: function () {
						$body.removeClass("loading");
				}
		});
	});

  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-24174284-23', 'orbitabar.com.br');
  ga('send', 'pageview');

</script>

</body>
</html>
